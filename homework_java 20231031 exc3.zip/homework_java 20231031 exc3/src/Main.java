public class Main {
    public static void main(String[] args) {
        String string = "AAAABBBCCCDDEG";
        System.out.println(method(string));
    }

    private static StringBuilder method(String text){
        StringBuilder result = new StringBuilder();
        char prevLetter = text.charAt(0);
        int count =0;
        for (int i = 0; i < text.length(); i++) {
            char currentLetter = text.charAt(i);
            if ( prevLetter == currentLetter){
                count++;
            } else {
                result.append(prevLetter);
                result.append(count == 1 ? "" : count);
                count = 1;
                prevLetter = currentLetter;
            }
        }
        result.append(prevLetter);
        result.append(count == 1 ? "" : count);
        return result;
        }
        }

/*
Задание 3. Задание из собеседования Яндекс:
        дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
        Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой.
         Если буква одна, то цифра не ставится.*/
